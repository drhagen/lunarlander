using System;

namespace LunarLander
{
	/// <summary>
	/// Summary description for Scores.
	/// </summary>

	public class Score
	{
		public string name;
		public int score;

		public Score()
		{
			name = null;
			score = 0;
		}

		public Score(string a, int b)
		{
			name = a;
			score = b;
		}

		public string getName()
		{
			return name;
		}

		public int getScore()
		{
			return score;
		}

		public void setName(string n)
		{
			name = n;
		}

		public void setScore(int s)
		{
			score = s;
		}
	}
}
